package com.project.capstone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.capstone.dvo.Job;
import com.project.capstone.service.JobService;

@CrossOrigin(origins = "*")

@RestController   // @Controller + @ResponseBody
@RequestMapping("/api/jobs")
public class JobController {
	

	    public JobController() {
	    	System.out.println("Job controller created");
	}

		@Autowired
	    private JobService jobService;
	    
//	    @PostMapping
//	    public ResponseEntity<Job> createJob(@RequestBody Job job) {
//	        Job savedJob = jobService.saveJob(job);
//	        return ResponseEntity.status(201).body(savedJob);
//	    }
	    @GetMapping("/hello")
	    public String hello() {
	    	return "hello";
	    }
	    @PostMapping
	    public Job createJob(@RequestBody Job job) {
	        return jobService.createJob(job);
	    }

	    // GET /api/jobs
	    @GetMapping   
	    public List<Job> getAllJobs() {
	        return jobService.getAllJobs();  
	       // Returns all job postings
	    }
	    
	    
	    

	    // GET /api/jobs/search?role={keyword}
	    @GetMapping("/search")
	    public List<Job> searchJobsByRole(@RequestParam("role") String keyword) {
	        return jobService.searchJobsByRole(keyword);
	        //Searches jobs by title
	    }

	    // GET /api/jobs/{id}
	    @GetMapping("/{id}")
	    public Job getJobById(@PathVariable Long id) {
	        return jobService.getJobById(id);
	        // Gets a specific job by ID
	    }
	

}
