package com.project.capstone.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.capstone.dvo.Application;

public interface ApplicationRepository extends JpaRepository<Application, Long> {
	List<Application> findByJobId(Long jobId);

}
