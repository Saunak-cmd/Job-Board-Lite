package com.project.capstone.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.capstone.dvo.Job;

@Repository
public interface JobRepository extends JpaRepository<Job, Long> {
	List<Job> findByTitleContainingIgnoreCase(String keyword);
	//Add search query method fro search jobs by roless

}
