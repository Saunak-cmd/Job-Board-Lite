package com.project.capstone.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.capstone.dvo.Job;
import com.project.capstone.repo.JobRepository;

@Service
public class JobService {
	@Autowired
	private JobRepository jobRepository;  //created obj from jobReposoitiry interface
	
	
	public Job createJob(Job job) {
        return jobRepository.save(job);
    }
	
	public Job saveJob(Job job) {
        return jobRepository.save(job);
    }
	
	public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

    public Job getJobById(Long id) {
        return jobRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Job not found with ID: " + id));
    }

   
    
    public Job updateJob(Long id, Job jobDetails) {
        Job job = getJobById(id);

        job.setTitle(jobDetails.getTitle());
        job.setCompany(jobDetails.getCompany());
        job.setLocation(jobDetails.getLocation());
        job.setDescription(jobDetails.getDescription());
        job.setSalaryRange(jobDetails.getSalaryRange());
        job.setRequiredSkills(jobDetails.getRequiredSkills());

        return jobRepository.save(job);
    }

    public void deleteJob(Long id) {
        jobRepository.deleteById(id);
    }
    
    
    public List<Job> searchJobsByRole(String keyword) {
        return jobRepository.findByTitleContainingIgnoreCase(keyword); // Add search method in for Role based job search
    }

	
	
}

