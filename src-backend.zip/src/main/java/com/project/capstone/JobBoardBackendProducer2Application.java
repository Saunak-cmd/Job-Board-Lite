package com.project.capstone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobBoardBackendProducer2Application {

	public static void main(String[] args) {
		SpringApplication.run(JobBoardBackendProducer2Application.class, args);
	}

}
