import axios from 'axios';
 
const API_BASE_URL = 'http://localhost:8087/api/jobs';
 
export const fetchJobs = () => axios.get(API_BASE_URL);
// export const searchJobs = (role) => axios.get(`${API_BASE_URL}/search?role=${role}`);
// export const fetchJobDetails = (id) => axios.get(`${API_BASE_URL}/${id}`);
 
 
 
 
 
// Function to search jobs by role (or other parameters as needed)
// export const searchJobs = (role) => axios.get(`${API_BASE_URL}/search?title=${role}`); // You might want to search by title or other parameters
 
// Function to fetch job details by id
export const fetchJobDetails = (id) => axios.get(`${API_BASE_URL}/${id}`);
 
 