import React from 'react';
import { Link } from 'react-router-dom';

function Header() {
  return (
    <header className="bg-dark text-white p-3 mb-4">
      <div className="container-fluid d-flex justify-content-between align-items-center">
        <h2 className="mb-0">Job Board Lite</h2>
        <nav>
          
          
        </nav>
      </div>
    </header>
  );
}

export default Header;
