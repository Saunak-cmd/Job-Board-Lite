// import React from 'react';
// import { Link } from 'react-router-dom';
// import Header from './Header';
// import JobDetails from './JobDetails';
// import JobSearch from './JobSearch';
// import JobList from './JobList';

// function LandingPage() {
//   return (
    
   
//     <div className="container text-center mt-0">
//       <h1>Welcome to Job Board Lite</h1>
//       <p>Your new job opportunities await</p>

      
//       <JobSearch/>
//       <JobList/>
      

//     </div>
//   );
// }

// export default LandingPage;

import React from 'react';
import { Link } from 'react-router-dom';
import Header from './Header';
import JobDetails from './JobDetails';
import JobSearch from './JobSearch';
import JobList from './JobList';

function LandingPage() {
  return (
    <>
      <Header />

      <div className="container text-center mt-0">
        <h1>Welcome to Job Board Lite</h1>
        <p>Your new job opportunities await</p>

        <JobSearch />
        <JobList />
      </div>
    </>
  );
}

export default LandingPage;

