import React from 'react';
import { Link } from 'react-router-dom';

const ConfirmationMessage = () => {
  return (
    <div className="container mt-5">
      <h2>Application Submitted Successfully!</h2>
      <p>Thank you for applying. We'll get back to you soon.</p>
      <Link to="/" className="btn btn-primary mt-3">Back to Home</Link>
    </div>
  );
};

export default ConfirmationMessage;
