
// import React, { useState } from 'react';
// import axios from 'axios';
// import { useParams, useNavigate } from 'react-router-dom'; // ✅ add useNavigate here

// const API_BASE_URL = 'http://localhost:8087/api/applications'; // Backend API URL

// const JobApplicationForm = () => {
//   const { id } = useParams(); // Get jobId from URL
//   const navigate = useNavigate(); // ✅ initialize navigate

//   const [applicationData, setApplicationData] = useState({
//     fullName: '',
//     email: ''
//   });
//   const [error, setError] = useState('');

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setApplicationData({
//       ...applicationData,
//       [name]: value
//     });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const finalData = {
//         fullName: applicationData.fullName,
//         email: applicationData.email,
//         job: { jobid: id }
//       };

//       await axios.post(API_BASE_URL, finalData);
//       navigate('/confirmation'); 

//     } catch (error) {
//       console.error('Error submitting application:', error);
//       setError('Failed to submit application. Please try again.');
//     }
//   };

//   return (
//     <div className="container mt-5">
//       <h2>Job Application Form</h2>
//       {error && <div className="alert alert-danger">{error}</div>}
//       <form onSubmit={handleSubmit}>
//         <div className="mb-3">
//           <label htmlFor="fullName" className="form-label">Full Name</label>
//           <input
//             type="text"
//             className="form-control"
//             id="fullName"
//             name="fullName"
//             value={applicationData.fullName}
//             onChange={handleChange}
//             required
//           />
//         </div>
//         <div className="mb-3">
//           <label htmlFor="email" className="form-label">Email Address</label>
//           <input
//             type="email"
//             className="form-control"
//             id="email"
//             name="email"
//             value={applicationData.email}
//             onChange={handleChange}
//             required
//           />
//         </div>
//         <button type="submit" className="btn btn-success">Submit Application</button>
//       </form>
//     </div>
//   );
// };


// export default JobApplicationForm;




import React, { useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom'; // ✅ add useNavigate here
 
const API_BASE_URL = 'http://localhost:8087/api/applications'; // Backend API URL
 
const JobApplicationForm = () => {
  const { id } = useParams(); // Get jobId from URL
  const navigate = useNavigate(); // ✅ initialize navigate
 
  const [applicationData, setApplicationData] = useState({
    fullName: '',
    email: ''
  });
  const [error, setError] = useState('');
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setApplicationData({
      ...applicationData,
      [name]: value
    });
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const finalData = {
        fullName: applicationData.fullName,
        email: applicationData.email,
        job: { id: id }
      };
 
      await axios.post(API_BASE_URL, finalData);
      navigate('/confirmation');
 
    } catch (error) {
      console.error('Error submitting application:', error);
      setError('Failed to submit application. Please try again.');
    }
  };
 
  return (
    <div className="container mt-5">
      <h2>Job Application Form</h2>
      {error && <div className="alert alert-danger">{error}</div>}
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="fullName" className="form-label">Full Name</label>
          <input
            type="text"
            className="form-control"
            id="fullName"
            name="fullName"
            value={applicationData.fullName}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email Address</label>
          <input
            type="email"
            className="form-control"
            id="email"
            name="email"
            value={applicationData.email}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="btn btn-success">Submit Application</button>
      </form>
    </div>
  );
};
 
export default JobApplicationForm;
 
 