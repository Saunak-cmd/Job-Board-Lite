import { useState } from 'react';
 
function JobSearch({ onSearch }) {
  const [searchValue, setSearchValue] = useState('');
 
  const handleInputChange = (e) => {
    const value = e.target.value;
    setSearchValue(value);
    onSearch(value);
  };
 
  return (
    <div className="container mt-5">
      <div className="d-flex justify-content-center align-items-center flex-wrap gap-2">
        <div className="input-group w-50">
          <input
            type="text"
            className="form-control no-hover"
            value={searchValue}
            onChange={handleInputChange}
            placeholder="Search by Title"
            aria-label="Search Jobs"
          />
        </div>
      </div>
    </div>
  );
}
 
export default JobSearch;