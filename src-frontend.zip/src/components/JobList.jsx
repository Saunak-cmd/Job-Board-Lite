import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { fetchJobs } from '../api/Api'; // Assuming you're using your API helper

function JobList() {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetching jobs when component mounts
    fetchJobs()
      .then(response => {
        setJobs(response.data);
        console.log(response.data)
        setLoading(false);
      })
      .catch(error => {
        setError('Failed to load jobs');
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Loading jobs...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="container mt-5 p-4">
      <h2 className="mb-4">Available Job Openings</h2>
      <div className="row d-flex flex-wrap">
        {jobs.map((job) => (
          <div key={job.jobid} className="col-md-4 mb-4 d-flex">
            <div className="card border-dark w-100 h-100">
              <div className="card-body d-flex flex-column">
                <h5 className="card-title">{job.title}</h5>
                <p className="card-text"><strong>Company:</strong> {job.company}</p>
                <p className="card-text"><strong>Location:</strong> {job.location}</p>
                 <Link to={`/jobs/${job.id}`} className="btn btn-dark mt-auto">
                  View Details
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default JobList;
